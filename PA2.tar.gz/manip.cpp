/*
Jackson Moore
CPSC 1020
PA2
image manipulation implementations
*/



#include "manip.h"
using namespace std;

//inputs: image
//outputs: none
//grayscales image
void gray_scale(Image &image){
  unsigned char red, green, blue;
  int avg = 0;

  for(int row = 0; row < image.header().getHeight(); row++){
    for (int col = 0; col < image.header().getWidth(); col++){
      //calculates new rgb value for each pixel
      avg = (image(row,col).r() +image(row,col).g() +image(row,col).b() ) / 3;

      red = avg;
      blue = avg;
      green = avg;

      Pixel pixelVar(red,green,blue);
      image(row,col) = pixelVar;

    }
  }
}

//inputs: image
//outputs: none
//mirrors image
void mirror(Image &image){
  unsigned char red, green, blue;
  int avg = 0;

  for(int row = 0; row < image.header().getHeight(); row++){
    for (int col = 0; col < (image.header().getWidth()) / 2; col++){
      red = image(row,image.header().getWidth() - col).r();
      green = image(row,image.header().getWidth() - col).g();
      blue = image(row,image.header().getWidth() - col).b();
      Pixel pixelVar1(red,green,blue);
      red = image(row, col).r();
      green = image(row, col).g();
      blue = image(row,col).b();
      Pixel pixelVar2(red,green,blue);
      image(row,col) = pixelVar1;
      image(row,image.header().getWidth() - col) = pixelVar2;


}
}
}

//inputs: image and clemson paw
//outputs: none
//green screens clemson paw onto image
void green_screen(Image &image, Image &clemsonPaw){
unsigned char red, green, blue;
  for(int row = 0; row < clemsonPaw.header().getHeight(); row++){
    for (int col = 0; col < clemsonPaw.header().getWidth(); col++){
      if(clemsonPaw(row,col).r() == 0 && clemsonPaw(row,col).g() == 255 && clemsonPaw(row,col).b() == 0){

      }else{
        red = clemsonPaw(row,col).r();
        green = clemsonPaw(row,col).g();
        blue = clemsonPaw(row,col).b();
        Pixel pixelVar(red,green,blue);
        image(row,col) = pixelVar;
      }






}
}
}
