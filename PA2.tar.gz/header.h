/*
Jackson Moore
CPSC 1020
PA2
header class definition
*/

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class Header{
  private:
    string magicNum;
    int width, height, maxVal;
  public:
    //constructors
    Header();
    Header(string magic, int w, int h, int mx);
    Header(const Header &h);

    //getters
    string getMagic() const;
    int getWidth() const;
    int getHeight() const;
    int getMaxVal() const;
    string& getMagic();
    int& getWidth();
    int& getHeight();
    int& getMaxVal();

    //destructor
    ~Header();

};
