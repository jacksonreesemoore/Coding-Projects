/*
Jackson Moore
CPSC 1020
PA2
This program takes a ppm file in and converts it to a gray scale, mirrored
or green screen image.
*/



#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <array>
#include <vector>
#include "manip.h"
using namespace std;

int printMenu1();
int whichImage();

int main(int argc, char* argv[]) {

  if(argc != 3) {
    cout << "USAGE: <executable> <First Image> <Second Image>" << endl;
    return -1;
  }

  ifstream image1 (argv[1]);
  ifstream image2 (argv[2]);
  int choice = 1;
  int imgCount = 0;

  Image img1(image1);
  Image img2(image2);

  while (choice != 0){
    choice = printMenu1();
    string count = to_string(imgCount);
    string outImage = "out_"+count+".ppm";
    ofstream newImgFile (outImage);
    int var = 0;

     switch (choice){
      case 1:
      var = whichImage();
      if (var == 1){
        Image newImg(img1);
        gray_scale(newImg);
        newImg.write_to(newImgFile);
        imgCount++;
        break;
      }else if(var == 2){
        Image newImg(img2);
        gray_scale(newImg);
        newImg.write_to(newImgFile);
        imgCount++;
        break;
      }

      case 2:
      var = whichImage();
      if (var == 1){
        Image newImg(img1);
        mirror(newImg);
        newImg.write_to(newImgFile);
        imgCount++;
      }else{
        Image newImg(img2);
        mirror(newImg);
        newImg.write_to(newImgFile);
        imgCount++;
      }

      break;

      case 3:
      cout << "the clemson paw will now be placed on disney" << endl;
      Image newImg(img2);
      green_screen(newImg, img1);
      newImg.write_to(newImgFile);
      imgCount++;
      break;

    }

  }
  return 0;
}
//prints manipulation menu for user
int printMenu1(){
	int choice;
	cout << "PA1 Image Manipulation" << endl;
	cout << "0. exit program" << endl << "1. gray scale" << endl;
  cout << "2. mirror" << endl << "3. green screen" << endl;
	cin >> choice;
	if(choice == 0){
		exit(1);
	}else{
	return choice;
}

}

//prints image selection for user
int whichImage(){
  int image;
  cout << "PA1 Image Manipulation" << endl;
  cout << "1. ClemsonPaw.ppm" << endl;
  cout << "2. Disney.ppm" << endl;
  cin >> image;
  return image;
}
