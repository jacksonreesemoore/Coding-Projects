/*
Jackson Moore
CPSC 1020
PA2
image class definition
*/

#include "Pixel.h"
#include "header.h"
#include <vector>

class Image{
  private:
    Header theHeader;
    vector<Pixel> vectorPixels;
  public:
//Constructors
  Image();
  Image(ifstream &theFile);
  Image(const Image &image);
  std::vector<Pixel> read_pixels(Header h, ifstream &theFile);
  Header read_header(ifstream &theFile);
//output methods
    void write_header(ofstream& theFile);
    void write_to(ofstream& theFile);
//Getters
    Header header();
    vector<Pixel> pixels();
//Overloading operators
    Image& operator = (const Image& i);
    Pixel& operator()(int x, int y);
//destructor
    ~Image();

};
