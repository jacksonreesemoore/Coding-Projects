/*
Jackson Moore
CPSC 1020
PA2
pixel class definition
*/


#include <iostream>
#include <fstream>
using namespace std;

class Pixel{

  private:
    unsigned char red, green, blue;

  public:
    //constructors
    Pixel();
    Pixel(unsigned char r1, unsigned char g1, unsigned char b1);
    Pixel(const Pixel &obj);

    //rgb getters
    unsigned char r() const;
    unsigned char g() const;
    unsigned char b() const;

    unsigned char& r();
    unsigned char& g();
    unsigned char& b();

    //overloaded operators
    Pixel& operator = (const Pixel& p);
    friend std::ostream& operator<<(std::ostream& out, const Pixel& p);

    //destructor
    ~Pixel();


};
