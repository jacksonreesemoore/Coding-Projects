/*
Jackson Moore
CPSC 1020
PA2
image manip function definitions
*/



#include "image.h"
#include <iostream>
#include <fstream>
using namespace std;

void gray_scale(Image &image);

void mirror(Image &image);

void green_screen(Image &image, Image &clemsonPaw);
