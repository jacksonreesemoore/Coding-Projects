/*
Jackson Moore
CPSC 1020
PA2
pixel class implementation
*/



#include "Pixel.h"
using namespace std;

//constructors
Pixel::Pixel(){
  red = green = blue = 0;
}
Pixel::Pixel(unsigned char red1, unsigned char green1, unsigned char blue1){
  red = red1; green = green1; blue = blue1;
}
Pixel::Pixel(const Pixel &p){
  red = p.red;
  green = p.green;
  blue = p.blue;
}
unsigned char Pixel::r()const{
  return red;
}
unsigned char Pixel::g()const{
  return green;
}
unsigned char Pixel::b()const{
  return blue;
}
unsigned char& Pixel::r(){
  return red;
}
unsigned char& Pixel::g(){
  return green;
}
unsigned char& Pixel::b(){
  return blue;
}

//overloaded operators
Pixel& Pixel::operator = (const Pixel &P){
  red = P.red;
  green = P.green;
  blue = P.blue;
  return *this;
}
ostream &operator<<(ostream &out, const Pixel &p){
  out<<p.red;
  out<<p.green;
  out<<p.blue;
  return(out);
}

Pixel::~Pixel(){
  return;
}
