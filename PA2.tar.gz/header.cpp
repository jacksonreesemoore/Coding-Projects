/*
Jackson Moore
CPSC 1020
PA2
header class implementations
*/


#include "header.h"
#include <vector>

using namespace std;

//Constructors
Header::Header(){
  string magicNum;
  width = height = maxVal = 0;
}

Header::Header(string magic, int w, int h, int mx){
  magicNum = magic;
  width = w;
  height = h;
  maxVal = mx;
}

Header::Header(const Header &h){
  this->magicNum = h.magicNum;
  this->width = h.width;
  this->height = h.height;
  this->maxVal = h.maxVal;
}

//getters
string Header::getMagic()const{
  return magicNum;
}
int Header::getWidth() const{
  return width;
}
int Header::getHeight() const{
  return height;
}
int Header::getMaxVal() const{
  return maxVal;
}
string& Header::getMagic(){
  return magicNum;
}
int& Header::getWidth(){
  return width;
}
int& Header::getHeight(){
  return height;
}
int& Header::getMaxVal(){
  return maxVal;
}

//destructor
Header::~Header(){
  return;
}
