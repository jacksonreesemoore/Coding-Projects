/*
Jackson Moore
CPSC 1020
PA2
image class implementations
*/


#include "image.h"
using namespace std;
//Constructors
    Image::Image(){
      return;
    }
    Image::Image(ifstream &theFile){
      this->theHeader = read_header(theFile);
      Header tempHeader = this->theHeader;
      this->vectorPixels = read_pixels(tempHeader, theFile);
    }
    Image::Image(const Image &image){
      this->vectorPixels = image.vectorPixels;
      this->theHeader = image.theHeader;
    }

    vector<Pixel> Image::read_pixels(Header h, ifstream &theFile){
      int var = h.getWidth() * h.getHeight();
      vector<Pixel> pixels(var);
      unsigned char r,g,b;
      for(int i = 0; i < var; i++){
        r = theFile.get();
        g = theFile.get();
        b = theFile.get();
        Pixel tempPixel(r,g,b);
        pixels[i] = tempPixel;
      }

      return pixels;
    }
    Header Image::read_header(ifstream &theFile){
      string magicVal;
      int heightVal, widthVal, maxVal;
      theFile>>magicVal;
      theFile>>heightVal;
      theFile>>widthVal;
      theFile>>maxVal;
      theFile.ignore(256,'\n');
      Header newHeader(magicVal,heightVal,widthVal,maxVal);
      return newHeader;
    }
//output methods
    void Image::write_header(ofstream& theFile){
      theFile<<this->theHeader.getMagic()<<" ";
      theFile<< this->theHeader.getWidth() << " ";
      theFile<< this->theHeader.getHeight() << " ";
      theFile<<this->theHeader.getMaxVal() << " ";
    }
    void Image::write_to(ofstream& theFile){
      write_header(theFile);

      for(Pixel& p : this->vectorPixels){
        theFile<< p.r() << p.g() << p.b();
      }
    }
//Getters
    Header Image::header(){
      return theHeader;
    }
    vector<Pixel> Image::pixels(){
      return vectorPixels;
    }
//Overloading operators
    Image& Image::operator = (const Image& obj){
      this->vectorPixels = obj.vectorPixels;
      this->theHeader = obj.theHeader;
            return *this;
      }
    Pixel& Image::operator()(int x, int y){
      int i = (theHeader.getWidth() *x) + y;
      return this->vectorPixels[i];
      }
//destructor
    Image::~Image(){
      return;
    }
