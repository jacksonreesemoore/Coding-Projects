package cpsc2150.extendedTicTacToe;

import cpsc2150.extendedTicTacToe.models.BoardPosition;
import cpsc2150.extendedTicTacToe.models.GameBoard;
import cpsc2150.extendedTicTacToe.models.GameBoardMem;
import cpsc2150.extendedTicTacToe.models.IGameBoard;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GameScreen {


    /**
     * @description gets the input from the player about where the marker should be placed
     *
     * @param player the player whose move it is
     * @return boardPosition that player will place their marker
     * @pre NONE
     * @post BoardPosition.row = player input AND BoardPosition.column = player input
     */
    public static BoardPosition nextMove(char player) {

        String r, c;
        int ar, ac;

        Scanner input = new Scanner(System.in);

        System.out.println("Player " + player + " Please enter your ROW");

        r = input.next();
        ar = Integer.parseInt(r);


        System.out.println("Player " + player + " Please enter your COLUMN");

        c = input.next();
        ac = Integer.parseInt(c);

        BoardPosition output = new BoardPosition(ar,ac);

        return output;
    }

    /**
     * @description prints the congratulatory message to the winner and asks if they want to play again
     * @param player to be declared winner
     *
     * @pre checkHorizontalWin == true for player OR checkDiagonalWin == true for player OR checkVerticalWin == true for player
     * @post message is printed and player is prompted for another round
     */
    public static void declareWinner(char player) {

        System.out.println("Player " + player + " wins!");

    }

    /**
     * @description runs the game
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        char playAgain = 'Y';
        BoardPosition currSpace;



        while (playAgain == 'Y' || playAgain == 'y') {

            int numPlayers = 0;

            List<Character> players = new ArrayList<Character>();
            String playerChoice;

            System.out.println("How many players?");
            numPlayers = input.nextInt();

            while(numPlayers < 2 || numPlayers > 10) {

                if(numPlayers > 10) {

                    System.out.println("Must be 10 players or fewer");
                    System.out.println("How many players?");
                    numPlayers = input.nextInt();

                }

                else if(numPlayers < 2) {

                    System.out.println("Must be at least 2 players");
                    System.out.println("How many players?");
                    numPlayers = input.nextInt();

                }
            }

            for(int i = 0; i < numPlayers; ++i) {

                System.out.println("Enter the character to represent player " + (i+1));

                playerChoice = input.next();

                if(!players.isEmpty()) {

                    while (players.contains(playerChoice.toUpperCase().charAt(0))) {

                        System.out.println(playerChoice.toUpperCase() + " is already taken as a player token!");

                        System.out.println("Enter the character to represent player " + i);

                        playerChoice = input.next();

                    }
                }

                playerChoice = playerChoice.toUpperCase();
                players.add(i, playerChoice.charAt(0));

            }

            System.out.println("How many rows?");
            int rowNum = input.nextInt();

            while(rowNum < 3 || rowNum > 100) {

                System.out.println("Rows must be between 3 and 100");
                System.out.println("How many rows?");
                rowNum = input.nextInt();

            }

            System.out.println("How many columns?");
            int colNum = input.nextInt();

            while(colNum < 3 || colNum > 100) {

                System.out.println("Columns must be between 3 and 100");
                System.out.println("How many columns?");
                colNum = input.nextInt();

            }

            System.out.println("How many in a row to win?");
            int numToWin = input.nextInt();

            while(numToWin < 3 || numToWin > 25) {

                System.out.println("Number in a row to win must be between 3 and 25");
                System.out.println("How many in a row to win?");
                numToWin = input.nextInt();

            }

            while(numToWin > colNum || numToWin > rowNum) {

                System.out.println("Number in a row to win must be less than the number of rows and columns");
                System.out.println("How many in a row to win?");
                numToWin = input.nextInt();

            }

            char gameType = ' ';
            System.out.println("Would you like a fast game (F/f) or a Memory Efficient Game (M/m)?");
            gameType = input.next().toUpperCase().charAt(0);

            while(gameType != 'F' && gameType != 'M') {

                System.out.println("Please enter F or M");
                gameType = input.next().toUpperCase().charAt(0);

            }

            char currPlayer = players.get(0);
            int playerIter = 1;

            IGameBoard board;

            if(gameType == 'F') {
                board = new GameBoard(rowNum, colNum, numToWin);
            }

            else {
                board = new GameBoardMem(rowNum, colNum, numToWin);
            }

            boolean win = false;

            while (!win) {
                System.out.println(board.toString());

                currSpace = nextMove(currPlayer);

                while ((currSpace.getRow() >= rowNum) || (currSpace.getColumn() >= colNum) ||
                        (currSpace.getRow() < 0) || currSpace.getColumn() < 0) {

                    System.out.println(board.toString());

                    System.out.println("That space is unavailable, please pick again");

                    currSpace = nextMove(currPlayer);

                }

                while (!board.checkSpace(currSpace)) {

                    System.out.println(board.toString());

                    System.out.println("That space is unavailable, please pick again");

                    currSpace = nextMove(currPlayer);

                }

                board.placeMarker(currSpace, currPlayer);

                if (board.checkForWinner(currSpace)) {

                    declareWinner(currPlayer);

                    System.out.println("Would you like to play again? Y/N");

                    playAgain = input.next().charAt(0);

                    win = true;

                } else if (board.checkForDraw()) {

                    System.out.println("The game has resulted in a draw!");

                    System.out.println("Would you like to play again? Y/N");

                    playAgain = input.next().charAt(0);

                    win = true;

                } else {

                    if (playerIter == players.size()) {

                        playerIter = 0;

                    }
                    currPlayer = players.get(playerIter);

                    playerIter++;


                }
            }
        }
    }
}
