package cpsc2150.extendedTicTacToe.models;

import cpsc2150.extendedTicTacToe.models.BoardPosition;
import cpsc2150.extendedTicTacToe.models.GameBoard;
import cpsc2150.extendedTicTacToe.models.GameBoardMem;
import cpsc2150.extendedTicTacToe.models.IGameBoard;
import org.junit.Test;
import static org.junit.Assert.*;

@SuppressWarnings("StringConcatenationInLoop")
public class TestGameBoardMem {
    private IGameBoard MakeAGB(int rows, int cols, int numToWin) {

        return new GameBoardMem(rows, cols, numToWin);

    }

    private String expectedString(char[][] array, int r, int c) {

        String board = "   ";
        for (int i = 0; i < c; ++i) {
            if (i <= 9) {

                board += " " + i + "|";
            } else {

                board += i + "|";
            }
        }

        board += "\n";

        for (int j = 0; j < r; ++j) {

            if (j <= 9) {
                board += " " + j + "|";
            } else {
                board += j + "|";
            }
            for (int k = 0; k < c; ++k) {

                board += array[j][k] + " |";

            }

            board += "\n";
        }

        return board;
    }

    @Test
    public void testConstructor_smallBoard() {
        IGameBoard gb = MakeAGB(3, 3, 3);

        char[][] array = new char[3][3];

        for(int i = 0; i < 3; ++i) {
            for(int j = 0; j < 3; ++j) {

                array[i][j] = ' ';

            }
        }

        String actual = gb.toString();
        String expected = expectedString(array, 3, 3);

        assertEquals(expected, actual);

    }

    @Test
    public void testConstructor_bigBoard() {
        IGameBoard gb = MakeAGB(100, 100, 25);

        char[][] array = new char[100][100];

        for(int i = 0; i < 100; ++i) {
            for(int j = 0; j < 100; ++j) {

                array[i][j] = ' ';

            }
        }

        String actual = gb.toString();
        String expected = expectedString(array, 100, 100);

        assertEquals(expected, actual);

    }

    @Test
    public void testConstructor_unevenBoard() {
        IGameBoard gb = MakeAGB(12, 15, 10);

        char[][] array = new char[12][15];

        for(int i = 0; i < 12; ++i) {
            for(int j = 0; j < 15; ++j) {

                array[i][j] = ' ';

            }
        }

        String actual = gb.toString();
        String expected = expectedString(array, 12, 15);

        assertEquals(expected, actual);

    }

    @Test
    public void testCheckSpace_checkFirstSpace() {
        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(0,0);

        assert(gb.checkSpace(test));

    }

    @Test
    public void testCheckSpace_checkLastSpace() {
        IGameBoard gb = MakeAGB(5, 5, 5);
        BoardPosition test = new BoardPosition(4,4);

        gb.placeMarker(test, 'X');

        assert(!gb.checkSpace(test));

    }

    @Test
    public void testCheckSpace_checkMiddleSpace() {
        IGameBoard gb = MakeAGB(6, 5, 5);
        BoardPosition test = new BoardPosition(1,2);

        gb.placeMarker(test, 'X');

        assert(!gb.checkSpace(test));

    }

    @Test
    public void testCheckHorizontalWin_last_marker_middle() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(1,0);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,4);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(1,2);
        gb.placeMarker(test, 'X');

        assert(gb.checkHorizontalWin(test, 'X'));
    }

    @Test
    public void testCheckHorizontalWin_last_marker_right() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(4,0);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(4,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(4,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(4,3);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        assert(gb.checkHorizontalWin(test, 'X'));
    }

    @Test
    public void testCheckHorizontalWin_last_marker_left() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,1);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(3,0);
        gb.placeMarker(test, 'X');

        assert(gb.checkHorizontalWin(test, 'X'));
    }

    @Test
    public void testCheckHorizontalWin_diff_marker() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(3,0);
        gb.placeMarker(test, 'O');

        test = new BoardPosition(3,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,3);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');

        assert(!gb.checkHorizontalWin(test, 'X'));
    }

    @Test
    public void testCheckVerticalWin_last_marker_middle() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(4,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(0,1);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(2,1);
        gb.placeMarker(test, 'X');

        assert(gb.checkVerticalWin(test, 'X'));
    }

    @Test
    public void testCheckVerticalWin_last_marker_top() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,4);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(0,4);
        gb.placeMarker(test, 'X');

        assert(gb.checkVerticalWin(test, 'X'));
    }

    @Test
    public void testCheckVerticalWin_last_marker_bottom() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(0,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        assert(gb.checkVerticalWin(test, 'X'));
    }

    @Test
    public void testCheckVerticalWin_diff_marker() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(0,4);
        gb.placeMarker(test, 'O');

        test = new BoardPosition(1,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        assert(!gb.checkVerticalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_middle_left_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(0,0);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,3);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(2,2);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_top_left_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 4);

        BoardPosition test = new BoardPosition(4,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,0);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_bottom_left_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 4);

        BoardPosition test = new BoardPosition(0,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,4);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_middle_right_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 5);

        BoardPosition test = new BoardPosition(0,4);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(4,0);
        gb.placeMarker(test, 'X');


        test = new BoardPosition(2,2);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_top_right_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 4);

        BoardPosition test = new BoardPosition(4,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,4);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_last_marker_bottom_right_diagonal() {

        IGameBoard gb = MakeAGB(5, 5, 4);

        BoardPosition test = new BoardPosition(0,3);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,2);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(3,0);
        gb.placeMarker(test, 'X');

        assert(gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckDiagonalWin_diff_marker() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(0,2);
        gb.placeMarker(test, 'O');

        test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(2,0);
        gb.placeMarker(test, 'X');

        assert(!gb.checkDiagonalWin(test, 'X'));
    }

    @Test
    public void testCheckForDraw_empty_board() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        assert(!gb.checkForDraw());
    }

    @Test
    public void testCheckForDraw_full_board() {

        IGameBoard gb = MakeAGB(5, 5, 3);
        BoardPosition test;
        for(int i = 0; i < 5; ++i) {
            for(int j = 0; j < 5; ++j) {

                test = new BoardPosition(i,j);
                gb.placeMarker(test, 'X');

            }
        }

        assert(gb.checkForDraw());
    }

    @Test
    public void testCheckForDraw_partial_board() {

        IGameBoard gb = MakeAGB(5, 5, 3);
        BoardPosition test;
        for(int i = 0; i < 5; ++i) {
            for(int j = 0; j < 5; ++j) {

                test = new BoardPosition(i,j);
                gb.placeMarker(test, 'X');

            }
        }

        test = new BoardPosition(1,3);
        gb.placeMarker(test, ' ');

        test = new BoardPosition(2,2);
        gb.placeMarker(test, ' ');

        test = new BoardPosition(3,3);
        gb.placeMarker(test, ' ');

        test = new BoardPosition(4,1);
        gb.placeMarker(test, ' ');

        assert(!gb.checkForDraw());
    }

    @Test
    public void testCheckForDraw_lastPos_filled() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(4,4);
        gb.placeMarker(test, 'X');

        assert(!gb.checkForDraw());
    }

    @Test
    public void testWhatsAtPos_correct_symbol() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');


        assertEquals('X', gb.whatsAtPos(test));
    }

    @Test
    public void testWhatsAtPos_empty() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(1,1);

        assertEquals(' ', gb.whatsAtPos(test));
    }

    @Test
    public void testWhatsAtPos_correct_symbol_surrounded() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,0);
        gb.placeMarker(test, 'a');

        test = new BoardPosition(0,1);
        gb.placeMarker(test, 'c');

        test = new BoardPosition(1,2);
        gb.placeMarker(test, 'b');


        test = new BoardPosition(2,1);
        gb.placeMarker(test, 'o');

        assertEquals('X', gb.whatsAtPos(new BoardPosition(1,1)));
    }

    @Test
    public void testWhatsAtPos_big_board() {

        IGameBoard gb = MakeAGB(9, 9, 9);

        BoardPosition test = new BoardPosition(4,3);
        gb.placeMarker(test, 'X');

        assertEquals('X', gb.whatsAtPos(test));
    }

    @Test
    public void testWhatsAtPos_small_board() {

        IGameBoard gb = MakeAGB(3, 3, 3);

        BoardPosition test = new BoardPosition(1,2);
        gb.placeMarker(test, 'X');

        assertEquals('X', gb.whatsAtPos(test));
    }

    @Test
    public void testIsPlayerAtPos_empty_pos() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(2,0);
        gb.placeMarker(test, 'X');

        assert(!gb.isPlayerAtPos(new BoardPosition(2,2), 'X'));
    }

    @Test
    public void testIsPlayerAtPos_wrong_marker() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(2,0);
        gb.placeMarker(test, 'X');

        test = new BoardPosition(1,1);
        gb.placeMarker(test, 'O');

        assert(!gb.isPlayerAtPos(new BoardPosition(1,1), 'X'));
    }

    @Test
    public void testIsPlayerAtPos_correct() {

        IGameBoard gb = MakeAGB(5, 5, 3);

        BoardPosition test = new BoardPosition(1,1);
        gb.placeMarker(test, 'X');

        assert(gb.isPlayerAtPos(new BoardPosition(1,1), 'X'));
    }

    @Test
    public void testIsPlayerAtPos_big_board() {

        IGameBoard gb = MakeAGB(9, 9, 9);

        BoardPosition test = new BoardPosition(4,3);
        gb.placeMarker(test, 'X');

        assert(gb.isPlayerAtPos(new BoardPosition(4,3), 'X'));
    }

    @Test
    public void testIsPlayerAtPos_small_board() {

        IGameBoard gb = MakeAGB(3, 3, 3);

        BoardPosition test = new BoardPosition(1,2);
        gb.placeMarker(test, 'X');

        assert(gb.isPlayerAtPos(new BoardPosition(1,2), 'X'));
    }

    @Test
    public void testPlaceMarker_correct() {
        IGameBoard gb = MakeAGB(5, 5, 3);

        int rows = 5;
        int cols = 5;
        char[][] array = new char[rows][cols];

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                array[i][j] = ' ';

            }
        }

        gb.placeMarker(new BoardPosition(1,1), 'X');
        array[1][1] = 'X';

        String actual = gb.toString();
        String expected = expectedString(array, rows, cols);

        assertEquals(expected, actual);

    }

    @Test
    public void testPlaceMarker_multiple_players() {
        IGameBoard gb = MakeAGB(5, 5, 3);

        int rows = 5;
        int cols = 5;
        char[][] array = new char[rows][cols];

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                array[i][j] = ' ';

            }
        }

        gb.placeMarker(new BoardPosition(0,3), 'b');
        array[0][3] = 'b';

        gb.placeMarker(new BoardPosition(1,0), 'X');
        array[1][0] = 'X';

        gb.placeMarker(new BoardPosition(2,1), 'a');
        array[2][1] = 'a';

        gb.placeMarker(new BoardPosition(3,2), 'c');
        array[3][2] = 'c';

        String actual = gb.toString();
        String expected = expectedString(array, rows, cols);

        assertEquals(expected, actual);

    }

    @Test
    public void testPlaceMarker_fill_board() {
        IGameBoard gb = MakeAGB(5, 5, 3);

        int rows = 5;
        int cols = 5;
        char[][] array = new char[rows][cols];

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                array[i][j] = 'X';

            }
        }

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                gb.placeMarker(new BoardPosition(i,j), 'X');

            }
        }

        String actual = gb.toString();
        String expected = expectedString(array, rows, cols);

        assertEquals(expected, actual);

    }

    @Test
    public void testPlaceMarker_big_board() {
        IGameBoard gb = MakeAGB(10, 10, 5);

        int rows = 10;
        int cols = 10;
        char[][] array = new char[rows][cols];

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                array[i][j] = ' ';

            }
        }

        gb.placeMarker(new BoardPosition(4,5), 'O');
        array[4][5] = 'O';

        String actual = gb.toString();
        String expected = expectedString(array, rows, cols);

        assertEquals(expected, actual);

    }

    @Test
    public void testPlaceMarker_small_board() {
        IGameBoard gb = MakeAGB(3, 3, 3);

        int rows = 3;
        int cols = 3;
        char[][] array = new char[rows][cols];

        for(int i = 0; i < rows; ++i) {
            for(int j = 0; j < cols; ++j) {

                array[i][j] = ' ';

            }
        }

        gb.placeMarker(new BoardPosition(2,2), 'X');
        array[2][2] = 'X';

        String actual = gb.toString();
        String expected = expectedString(array, rows, cols);

        assertEquals(expected, actual);

    }
}
