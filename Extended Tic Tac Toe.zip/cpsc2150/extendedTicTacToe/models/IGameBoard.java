package cpsc2150.extendedTicTacToe.models;

import static java.lang.Math.abs;

/**
 *
 * Description:
 * game board is a 2D array that allows players to place an X or O and
 * getting 5 consecutive markers of the same type in a row results in a win
 *
 * Initialization ensures:
 * GameBoard contains only ' ' characters and is rowMax x columnMax
 *
 * Defines:
 * rowMax = 4
 * columnMax = 7
 *
 * Constraints:
 * 0 <= row <= rowMax
 * 0 <= column <= columnMax
 */
public interface IGameBoard {

    public static final int rowMax = 100;
    public static final int rowMin = 3;
    public static final int columnMax = 100;
    public static final int colMin = 3;
    public static final int numToWinMax = 25;
    public static final int numToWinMin = 3;



    /**
     * @description checks if a space is valid to play on
     * @param pos is the space to be checked
     * @return true if the position is open, false if not
     *
     * @pre pos.column[col] AND pos.row[row]
     * @post checkSpace = true OR checkSpace = false
     */
    default public boolean checkSpace(BoardPosition pos) {
        return whatsAtPos(pos) == ' ';
    }

    /**
     * @description places marker on pos
     * @param marker spot to be marked
     * @param player player the spot is marked for
     *
     * @pre player == X OR player == O AND marker.column[col] AND marker.row[row]
     *
     * @post marker = player
     */
    public void placeMarker(BoardPosition marker, char player);

    /**
     * @description checks if a player has won by using checkVerticalWin, checkHorizontalWin, checkDiagonalWin
     * @param lastPos the last marked board position
     * @return true if the last marked board position resulted in a win, false if not
     *
     * @pre lastPos.column[col] AND lastPos.row[row] AND [pos is the last position played]
     * @post checkForWinner = true OR checkForWinner = false
     */
    default public boolean checkForWinner(BoardPosition lastPos) {

        if (checkVerticalWin(lastPos, whatsAtPos(lastPos))) {

            return true;

        }

        else if (checkHorizontalWin(lastPos, whatsAtPos(lastPos))) {

            return true;

        }
        else if (checkDiagonalWin(lastPos, whatsAtPos(lastPos))) {

            return true;

        }

        else {

            return false;

        }
    }

    /**
     * @description checks if there are any empty spaces remaining
     * @return true if a draw has occurred, false if not
     *
     * @pre No player has won
     * @post checkForDraw = true OR checkForDraw = false
     */
    default public boolean checkForDraw() {

        for (int i = 0; i < getNumRows(); ++i) {

            for (int j = 0; j < getNumColumns(); ++j) {


                BoardPosition curr = new BoardPosition(i,j);

                if (whatsAtPos(curr) == ' ') {

                    return false;

                }
            }
        }
        return true;
    }

    /**
     * @description checks for 5 spots in a row horizontally
     * @param lastPos the last marked board position
     * @param player player who may have 5 spots in a row
     * @return true if player has won, false if not
     *
     * @pre lastPos.column[col] AND lastPos.row[row] AND player == X OR player == O
     * @post checkHorizontalWin = true OR checkHorizontalWin = false
     */
    default public boolean checkHorizontalWin(BoardPosition lastPos, char player){

        int count = 0;

        for (int i = 0; i < getNumColumns(); ++i) {

            if (whatsAtPos(new BoardPosition(lastPos.getRow(), i)) == player) {

                ++count;
            }

            else  {

                count = 0;
            }

            if (count == getNumToWin()) {

                return true;

            }
        }

        return false;

    }

    /**
     * @description checks for 5 spots in a row vertically
     * @param lastPos the last marked board position
     * @param player player who may have 5 spots in a row
     * @return true if player has won, false if not
     *
     * @pre lastPos.column[col] AND lastPos.row[row] AND player == X OR player == O
     * @post checkVerticalWin = true OR checkVerticalWin = false
     */
    default public boolean checkVerticalWin(BoardPosition lastPos, char player){


        int count = 0;

        for (int i = 0; i < getNumRows(); ++i) {

            if (whatsAtPos(new BoardPosition(i, lastPos.getColumn())) == player) {

                ++count;
            }

            else if (whatsAtPos(new BoardPosition(i, lastPos.getColumn())) != player) {

                count = 0;
            }

            if (count == getNumToWin()) {

                return true;

            }
        }

        return false;

    }


    /**
     * @description checks for 5 spots in a row diagonally
     * @param lastPos the last marked board position
     * @param player player who may have 5 spots in a row
     * @return true if player has won, false if not
     *
     * @pre lastPos.column[col] AND lastPos.row[row] AND player == X OR player == O
     * @post checkDiagonalWin = true OR checkDiagonalWin = false
     */
    default public boolean checkDiagonalWin(BoardPosition lastPos, char player) {

        int count = 0;

        int currRow = 0;
        int currCol = 0;
        if(lastPos.getColumn() != 0){
            currCol = lastPos.getColumn() - lastPos.getRow();
        }

        //check first diagonal; tries to find first entry in diagonal
        //in the first column, if it finds it, iterates through the diagonal
        //to find if there are the correct amount in a row to win
        if (currRow <= currCol) {

            for (int i = 0; i < getNumRows(); i++) {

                if(currCol >= getNumColumns()){

                    break;

                }
                if (whatsAtPos(new BoardPosition(currRow, currCol)) == player) {

                    count++;

                }

                currRow++;

                if (currCol - 1 >= getNumColumns()) {

                    break;

                }

                if(count != 0){
                    currCol++;
                }

                if (count == getNumToWin()) {

                    return true;

                }
            }
        }

        currRow = 0;
        currCol = 0;
        if(lastPos.getColumn() != 0){
            currCol = lastPos.getColumn() - lastPos.getRow();
        }

        //check first diagonal; tries to find first entry in diagonal
        //in the first row, if it finds it, iterates through the diagonal
        //to find if there are the correct amount in a row to win
        if (currRow <= currCol) {

            for (int i = 0; i < getNumRows(); i++) {

                if(currCol >= getNumColumns()){

                    break;

                }
                if (whatsAtPos(new BoardPosition(currRow, currCol)) == player) {

                    count++;

                }

                if(count != 0){
                    currRow++;
                }

                if (currCol - 1 >= getNumColumns()) {

                    break;

                }

                    currCol++;

                if (count == getNumToWin()) {

                    return true;

                }
            }
        }

        count = 0;

        currRow = 0;
        currCol = getNumColumns() - 1;

        //check other diagonal; tries to find first entry in diagonal
        //in the last column, if it finds it, iterates through the diagonal
        //to find if there are the correct amount in a row to win
        for (int i = 0; i < getNumRows(); ++i) {

            if(currCol < getNumColumns()) {
                if (whatsAtPos(new BoardPosition(currRow, currCol)) == player) {

                    count++;

                }

                currRow++;

                if (count == getNumToWin()) {

                    return true;

                }

                if (currCol <= 0) {

                    break;

                }

                if(count != 0){
                    currCol--;
                }

            }
        }

        count = 0;

        currRow = 0;
        currCol = getNumColumns() - 1;

        //check other diagonal; tries to find first entry in diagonal
        //in the first row, if it finds it, iterates through the diagonal
        //to find if there are the correct amount in a row to win
        for (int i = 0; i < getNumRows(); ++i) {

            if(currCol < getNumColumns()) {
                if (whatsAtPos(new BoardPosition(currRow, currCol)) == player) {

                    count++;

                }

                if(count != 0){

                    currRow++;

                }

                if (count == getNumToWin()) {

                    return true;

                }

                if (currCol <= 0) {

                    break;

                }

                    currCol--;

            }
        }

        return false;

    }


    /**
     * @description tells what marker is at pos
     * @param pos board position getting checked
     * @return the player marker or empty space that is at pos
     *
     * @pre pos.column[col] AND pos.row[row] AND pos is a valid position
     * @post whatsAtPos = X OR whatsAtPos = O OR whatsAtPos = ' '
     */
    public char whatsAtPos(BoardPosition pos);

    /**
     * @description tells if player is at pos
     * @param pos board position being checked
     * @param player player marker being checked for at pos
     * @return true if the player is at the spot, false if not
     *
     * @pre pos.column[col] AND pos.row[row] AND player = X OR player = O AND pos is a valid position
     * @post isPlayerAtPos = true OR isPlayerAtPos = false
     */
    default public boolean isPlayerAtPos(BoardPosition pos, char player) {

        if (whatsAtPos(pos) == player) {

            return true;

        }

        return false;

    }

    public int getNumRows();
    public int getNumColumns();

    public int getNumToWin();

}
