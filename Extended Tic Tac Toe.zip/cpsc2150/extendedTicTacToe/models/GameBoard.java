package cpsc2150.extendedTicTacToe.models;

/**
 * @invariant 3 <= col <= columnMax AND 3 <= row <= rowMax
 * AND numToWinMin <= numToWin <= numToWinMax
 *
 * @correspondence self = #self
 */
public class GameBoard extends AbsGameBoard implements IGameBoard{

    private int numToWin;
    private int numRows;
    private int numCols;
    private char[][] board;
    /**
     * @description creates a gameboard
     * @post a 2D array of BoardPositions is created with each position holding an empty space ' '
     */
    public GameBoard(int rows, int cols, int numWin) {

        if(rowMin <= rows && rows <= rowMax && colMin <= cols && cols <= columnMax
        && numToWinMin <= numWin && numWin <= numToWinMax) {

            numToWin = numWin;
            numCols = cols;
            numRows = rows;

            board = new char[numRows][numCols];

            for (int i = 0; i < rows; ++i) {
                for (int j = 0; j < cols; ++j) {

                    board[i][j] = ' ';

                }
            }
        }
    }


    public void placeMarker(BoardPosition marker, char player)
    {
        board[marker.getRow()][marker.getColumn()] = player;
        //places the character in marker on the position specified by
        //marker and should not be called if the space is unavailable.
    }

    public char whatsAtPos(BoardPosition pos)
    {

        return board[pos.getRow()][pos.getColumn()];

        //returns what is in the GameBoard at position pos
        //If no marker is there, it returns a blank space char.
    }



    /**
     * @description returns rowMax
     * @return rowMax
     *
     * @post rowMax is returned
     */
    public int getNumRows() {

        return numRows;

    }

    /**
     * @description returns columnMax
     * @return columnMax
     *
     * @post columnMax is returned
     */
    public int getNumColumns() {

        return numCols;

    }

    /**
     * @description returns numToWin
     * @return numToWin
     *
     * @post numToWin is returned
     */

    public int getNumToWin() {

        return numToWin;

    }

}
