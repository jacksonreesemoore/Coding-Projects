package cpsc2150.extendedTicTacToe.models;

public abstract class AbsGameBoard implements IGameBoard{

    /**
     * @description prints the board in its current state
     * @post toString = [ String representation of the game board ] and self = #self
     * @return board in string format
     */
    @Override
    public String toString() {

        String board = "   ";
        for (int i =0; i < getNumColumns(); ++i) {
            if(i <= 9) {

                board += " " + i + "|";
            }
            else {

                board += i + "|";
            }
        }

        board += "\n";

        for (int j = 0; j < getNumRows(); ++j) {

            if(j <= 9) {
                board += " " + j + "|";
            }

            else {
                board += j + "|";
            }
            for (int k = 0; k < getNumColumns(); ++k) {

                BoardPosition curr = new BoardPosition(j, k);

                board += whatsAtPos(curr) + " |";

            }

            board += "\n";
        }

        return board;
    }
}
