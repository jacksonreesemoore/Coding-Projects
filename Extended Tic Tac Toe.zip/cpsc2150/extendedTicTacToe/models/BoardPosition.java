package cpsc2150.extendedTicTacToe.models;

/*
 * Jackson Moore
 * CPSC 2150 section 001
 * 10/20/2022
 */

/**
 * @invariant rowMax = 4 AND colMax = 7
 */


public class BoardPosition {

    private int row;
    private int column;

    /**
     * @description boardPosition creates an instance of the boardPosition class with the row and column values given
     *
     * @param r  takes in the row that the board position would be on
     *
     * @param c  takes in the column that the board position would be on
     *
     * @return NONE
     *
     * @pre 0 <= row <= rowMax AND 0 <= column <= colMax
     *
     * @post row = #row AND column = #column
     */
    public BoardPosition(int r, int c) {

        this.row = r;
        this.column = c;

    }

    /**
     * @description returns the row of boardPosition
     *
     * @return row number
     *
     * @pre 0 <= row <= rowMax
     *
     * @post NONE
     */
    public int getRow() {

        return row;

    }

    /**
     * @description returns the column of boardPosition
     *
     * @return column number
     *
     * @pre 0 <= column <= colMax
     *
     * @post NONE
     */
    public int getColumn() {

        return column;

    }


    /**
     * @description overrides the default method of equals to tells if two board positions are the same or not
     *
     * @param loc  takes in the boardPosition that is being compared
     *
     * @return returns true if the boardPositions are the same, false if not
     *
     * @pre 0 <= loc.row <= rowMax AND 0 <= loc.column <= colMax
     *
     * @post returns true if boardPositions are equal and false if not
     */
    @Override
    public boolean equals(Object loc) {

        if(loc instanceof BoardPosition) {

            if ((((BoardPosition)loc).row == row) && (((BoardPosition)loc).column == column)) {

                return true;

            }
        }

        return false;

    }

    /**
     * @description overrides the default method of toString to transforms boardPosition into string formatted as (row, column)
     *
     * @return BoardPosition is returned as row,column
     *
     * @pre 0 <= loc.row <= rowMax AND 0 <= loc.column <= colMax
     *
     * @post boardLocation is transformed to string format
     */
    @Override
    public String toString() {

        return row + "," + column;

    }
}
