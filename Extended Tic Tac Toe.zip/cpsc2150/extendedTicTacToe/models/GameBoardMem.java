package cpsc2150.extendedTicTacToe.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @invariant 0 <= col <= columnMax AND 0 <= row <= rowMax
 * AND numToWinMin <= numToWin <= numToWinMax
 *
 * @correspondence self = #self
 */
public class GameBoardMem extends AbsGameBoard implements IGameBoard{


    private int numToWin;
    private int numRows;
    private int numCols;

    private Map<Character, List<BoardPosition>> board;
    /**
     * @description creates a gameboard
     * @post an empty map with key of characters and a BoardPosition list as value is created
     */
    public GameBoardMem(int rows, int cols, int numWin) {

        if(rowMin <= rows && rows <= rowMax && colMin <= cols && cols <= columnMax
                && numToWinMin <= numWin && numWin <= numToWinMax) {

            numToWin = numWin;
            numCols = cols;
            numRows = rows;

            board = new HashMap<Character, List<BoardPosition>>();

        }
    }

    /**
     * @description places marker on pos
     * @param marker spot to be marked
     * @param player player the spot is marked for
     *
     * @pre player == X OR player == O AND marker.column[col] AND marker.row[row]
     *
     * @post marker = player
     */
    public void placeMarker(BoardPosition marker, char player) {

        if(board.containsKey(player)) {

            board.get(player).add(marker);

        }

        else {

            List<BoardPosition> list = new ArrayList<BoardPosition>();

            list.add(marker);

            board.put(player, list);

        }
    }

    /**
     * @description tells what marker is at pos
     * @param pos board position getting checked
     * @return the player marker or empty space that is at pos
     *
     * @pre pos.column[col] AND pos.row[row] AND pos is a valid position
     * @post whatsAtPos = X OR whatsAtPos = O OR whatsAtPos = ' '
     */
    public char whatsAtPos(BoardPosition pos) {

        for (Map.Entry<Character, List<BoardPosition>> m: board.entrySet()){

            if(m.getValue().contains(pos)) {

                return m.getKey();

            }
        }

        return ' ';
    }

    /**
     * @description tells if player is at pos
     * @param pos board position being checked
     * @param player player marker being checked for at pos
     * @return true if the player is at the spot, false if not
     *
     * @pre pos.column[col] AND pos.row[row] AND player = X OR player = O AND pos is a valid position
     * @post isPlayerAtPos = true OR isPlayerAtPos = false
     */
    @Override
    public boolean isPlayerAtPos(BoardPosition pos, char player) {

        if(!board.containsKey(player)) {

            return false;

        }

        else if(board.get(player).contains(pos)){

            return true;

        }

        return false;

    }



    public int getNumRows() {
        return numRows;
    }

    public int getNumColumns() {
        return numCols;
    }

    public int getNumToWin() {
        return numToWin;
    }
}
