/*
* Jackson Moore
* CPSC 2310 Fall 22
* PA1
* Username: jmoor35
* Instructor: Dr. Yvon Feaster
*/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

typedef struct header {
   char magicNum[3];
   int width, height, maxVal;
} header_t;


// Represents an RGB pixel with integer values between 0-255
typedef struct pixel {
  unsigned char r, g, b;
} pixel_t;

// will create a header object, read in the header info from the file
// into the header object, and return the header object back to read_ppm()
// inputs:  file pointer to the input image
// outputs: the header object containing the header info from the input file
header_t read_header(FILE* image_file);

// will write the header info to the output image file
// called from write_p6() function
// inputs:  file pointer to output image file & the header
// outputs:  none
void write_header(FILE* out_file, header_t header);

//will skip over comments in the header of the ppm image
//input: file to remove comments from
//output: none
char rcomment(FILE* in);

//creates a negative image of the inputted file
//input: output file and input file
//output: the negative image of the input file
FILE* negativePPM(FILE* inFp, FILE* outFp);

//creates a resized image of the inputted file
//input: output file, input file, new width, new height
//output: the resized image of the input file
FILE* resizePPM(FILE* inFp, FILE* outFp, int width, int height);

//allocates memory for a 2D array of pixels
//inputs: the size of the 2D array
//output: the 2D array of pixels that is dynamically allocated
pixel_t** allocate_memory(int height, int width);

//returns memory to system
//inputs: memory locations to be returned to system, height and width of location
//output: nothing
void free_memory(pixel_t** image, int height);
