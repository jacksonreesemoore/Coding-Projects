/*
* Jackson Moore
* CPSC 2310 Fall 22
* PA1
* Username: jmoor35
* Instructor: Dr. Yvon Feaster
*/

#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main(int argc, char* argv[])
{

    assert(argc == 4);

    FILE* inFp = fopen(argv[1], "r");
    FILE* resizeFp = fopen(argv[2], "w");
    FILE* negFp = fopen(argv[3], "w");

    assert(inFp != NULL);
    assert(resizeFp != NULL);
    assert(negFp != NULL);
    int width, height;

    printf("What height would you like to resize the image to?\n");
    scanf("%d", &height);

    printf("What width would you like to resize the image to?\n");
    scanf("%d", &width);

    negFp = negativePPM(inFp, negFp);
    rewind(inFp);
    resizeFp = resizePPM(inFp, resizeFp, width, height);

    fclose(inFp);
    fclose(resizeFp);
    fclose(negFp);

    return 0;
}
