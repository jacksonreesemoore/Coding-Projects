/*
* Jackson Moore
* CPSC 2310 Fall 22
* PA1
* Username: jmoor35
* Instructor: Dr. Yvon Feaster
*/

#include "functions.h"
#include <stdlib.h>

// will create a header object, read in the header info from the file
// into the header object, and return the header object back to read_ppm()
// inputs:  file pointer to the input image
// outputs: the header object containing the header info from the input file
header_t read_header(FILE* image_file) {
	header_t theHeader;
	char c;

  fscanf(image_file, "%s", theHeader.magicNum);

	fscanf(image_file, "%c", &c);
	while(c != '\n') {

		c = rcomment(image_file);

		}

		fscanf(image_file, "%c", &c);
		if (c == '#') {
				rcomment(image_file);
			}

   fscanf(image_file, "%d", &theHeader.width);

	 fscanf(image_file, "%c", &c);
	 while(c != '\n') {

 		c = rcomment(image_file);

		}
		fscanf(image_file, "%c", &c);
		if (c == '#') {
				rcomment(image_file);
			}

   fscanf(image_file, "%d", &theHeader.height);

	 fscanf(image_file, "%c", &c);
	 while(c != '\n') {

 	 c = rcomment(image_file);

	 }
	 fscanf(image_file, "%c", &c);
	 if (c == '#') {
			 rcomment(image_file);
		 }

   fscanf(image_file, "%d ", &theHeader.maxVal);

   return theHeader;
}


// will write the header info to the output image file
// called from write_p6() function
// inputs:  file pointer to output image file & the header
// outputs:  none
void write_header(FILE* out_file, header_t header) {
   fprintf(out_file, "%s\n%d\n%d\n%d\n",
      header.magicNum, header.width, header.height, header.maxVal);
}
//will skip over comments in the header of the ppm image
//input: file to remove comments from
//output: none
char rcomment(FILE* in) {

  char c;
  fscanf(in, "%c", &c);

  //goes through file until it reaches the end of the comment
  while (c != '\n') {

  fscanf(in, "%c", &c);

  }

	return c;
}

pixel_t** allocate_memory(int height, int width) {

	pixel_t** image = (pixel_t**)malloc(sizeof(pixel_t*) * height);

	for(int i = 0; i < height; ++i) {

		image[i] = (pixel_t*)malloc(sizeof(pixel_t) * width);

	}

	return image;

}

void free_memory(pixel_t** image, int height){

	for(int i = 0; i < height; ++i) {

		free(image[i]);

	}

	free(image);

}

FILE* negativePPM(FILE* inFp, FILE* outFp) {

	header_t header = read_header(inFp);

	write_header(outFp, header);

	pixel_t** image = allocate_memory(header.height,header.width);

	for(int i = 0; i < header.height; ++i) {

		fread(image[i], sizeof(pixel_t), header.width, inFp);

	}

	for(int row = 0; row < header.height; row++) {
		 for(int col = 0; col < header.width; col++) {

			 pixel_t temp = image[row][col];
			 //finds new values for negative pixels
			 temp.r = 255 - image[row][col].r;
			 temp.g = 255 - image[row][col].g;
			 temp.b = 255 - image[row][col].b;

			 image[row][col].r = temp.r;
			 image[row][col].g = temp.g;
			 image[row][col].b = temp.b;

		 }
	}

	for(int i = 0; i < header.height; ++i) {

	fwrite(image[i], sizeof(pixel_t), header.width, outFp);
	}
	free_memory(image, header.height);

	return outFp;

}

FILE* resizePPM(FILE* inFp, FILE* outFp, int width, int height){

	header_t header = read_header(inFp);

	pixel_t** image = allocate_memory(header.height, header.width);

	for(int i = 0; i < header.height; ++i) {

		fread(image[i], sizeof(pixel_t), header.width, inFp);

	}

	//calculate new dimensions and make sure they won't result in a negative
	//height or width
	int newWidth = header.width + width;
	int newHeight = header.height + height;

	while(newWidth < 0 || newHeight < 0) {

		printf("Cannot create an image with negative height or width\n");
		int widthIn, heightIn;

    printf("What height would you like to resize the image to?\n");
    scanf("%d", &heightIn);

    printf("What width would you like to resize the image to?\n");
    scanf("%d", &widthIn);

		newWidth = header.width + widthIn;
		newHeight = header.height + heightIn;

	}
	//calculate relative width and relative height
	double relWidth = (double)header.width / (double)newWidth;
	double relHeight = (double)header.height / (double)newHeight;

	int origHeight = header.height;

	header.height = newHeight;
	header.width = newWidth;

	write_header(outFp, header);

	pixel_t** newImage = allocate_memory(newHeight, newWidth);

	for(int row = 0; row < header.height; row++) {
		 for(int col = 0; col < header.width; col++) {

			 int relPixRow = (int)(row * relHeight);
			 int relPixCol = (int)(col * relWidth);

			 newImage[row][col] = image[relPixRow][relPixCol];

		 }
	}

	for(int i = 0; i < header.height; ++i) {

	fwrite(newImage[i], sizeof(pixel_t), header.width, outFp);

	}

	free_memory(image, origHeight);
	free_memory(newImage, newHeight);

	return outFp;
}
